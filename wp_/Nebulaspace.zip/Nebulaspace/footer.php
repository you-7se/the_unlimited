        
        <div class="footer-contents">
            <p>Powered by <a href="https://ja.wordpress.com/">WordPress</a></p>
            <p class="copyrights">UNLIMITED LOOP √1</p>
        </div>
        <?php wp_footer(); ?>
    </body>
</html>
